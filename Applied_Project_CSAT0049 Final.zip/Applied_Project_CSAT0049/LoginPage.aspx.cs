﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace Applied_Project_CSAT0049
{
    public partial class LoginPage : System.Web.UI.Page
    {
        string ConnectionString = "Data Source=ramyakrishna\\ramyasql;Initial Catalog=TechOnline;Integrated Security=True";
        string username, password;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection login_con = new SqlConnection(ConnectionString);
            login_con.Open();
            string login_qry = "select Username, Password from Login_Details where Username = '" + TextBox1.Text.ToString() + "'  and Password ='" + TextBox2.Text.ToString() + "' ; ";
            //  and Password ='" + TextBox2.Text.ToString() + "' 
            SqlCommand login_com = new SqlCommand(login_qry, login_con);
            SqlDataReader data_reader = login_com.ExecuteReader();
            while (data_reader.Read())
            {
                ReadSingleRow((IDataRecord)data_reader);
            }

            data_reader.Close();
            if (username == null && password == null)
            {
                // Response.Redirect("MainPage.aspx");

                Label3.Text = "* Invalid username or password";

            }
            else
            {
                //Label3.Text = "* Invalid username or password";

                Response.Redirect("MainPage.aspx");
            }

            void ReadSingleRow(IDataRecord record)
            {
                username = string.Format("{0}", record[0]);
                password = string.Format("{0}", record[1]);
            }

        }     /*
                if (TextBox1.Text == "techadmin" && TextBox2.Text == "admin121")
                {
                    Response.Redirect("MainPage.aspx");
                }
                else
                {
                    Label3.Text = "* Invalid username or password";

                }
                */
            
    }
}