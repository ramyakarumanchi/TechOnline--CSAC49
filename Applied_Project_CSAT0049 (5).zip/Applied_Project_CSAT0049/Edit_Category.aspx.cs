﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Applied_Project_CSAT0049
{
    public partial class Edit_Category : System.Web.UI.Page
    {
        string ConnectionString = "Data Source=DIXITHG\\DIXITHSQL;Initial Catalog=TechOnline;Integrated Security=True";
        string C_name_edit_product = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1_ID.Text = Session["Category_ID"].ToString();
            C_name_edit_product = Session["Category_Name"].ToString();
            
        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            
            SqlConnection Edit_Con = new SqlConnection(ConnectionString);
            Edit_Con.Open();
            string Edit_Qry = "UPDATE Category_Details SET C_Name = '"+TextBox1.Text.ToString()+ "' WHERE C_ID = '"+Label1_ID.Text.ToString()+"'; ";
            string Edit_Qry_product = "UPDATE Products_Details SET C_Name = '" + TextBox1.Text.ToString() + "' WHERE C_Name = '" + C_name_edit_product + "'; ";
            SqlCommand edit_cmd = new SqlCommand(Edit_Qry, Edit_Con);
            SqlCommand edit_prod_cmd = new SqlCommand(Edit_Qry_product, Edit_Con);
            edit_cmd.ExecuteNonQuery();
            edit_prod_cmd.ExecuteNonQuery();
            Label2_errMsg.Text = "Values updated successfully....";
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");
        }
    }
}