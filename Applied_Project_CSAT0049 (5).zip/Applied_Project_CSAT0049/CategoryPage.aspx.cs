﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace Applied_Project_CSAT0049
{
    public partial class CategoryPage : System.Web.UI.Page
    {
        string ConnectionString = "Data Source=DIXITHG\\DIXITHSQL;Initial Catalog=TechOnline;Integrated Security=True";
        int cnt;
        string ptn;
        protected void Page_Load(object sender, EventArgs e)
        {

            // Panel1.Controls.Add(btn);
            //string queryString = "SELECT COUNT(C_ID) from Category_Details;";
            string queryString = "SELECT MAX(C_ID) FROM Category_Details; ";
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Call Read before accessing data.
                while (reader.Read())
                {
                    ReadSingleRow((IDataRecord)reader);
                }

                // Call Close when done reading.
                reader.Close();
                /***************/
               
            }
            /***************/

            for (int r = 1; r <= cnt; r++)
            {
                TableRow row1 = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                Button btn = new Button();
                btn.ID = "btn12" + r;
                btn.Text = "Edit";
                btn.ForeColor = System.Drawing.Color.White;
                btn.BackColor = System.Drawing.Color.Maroon;
                Button btn_delete = new Button();
                btn_delete.ID = "btn_delete_" + r;
                btn_delete.Text = "Delete";
                btn_delete.ForeColor = System.Drawing.Color.White;
                btn_delete.BackColor = System.Drawing.Color.Maroon;
                string loc = "C_" + r;
                string cname = "";
                string queryString1 = "SELECT C_Name from Category_Details where C_ID = '" + loc + "';";

                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    SqlCommand command = new SqlCommand(queryString1, connection);
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    // Call Read before accessing data.
                    while (reader.Read())
                    {
                        ReadSingleRow1((IDataRecord)reader);
                    }

                    // Call Close when done reading.
                    reader.Close();
                    string queryString1_count = "SELECT COUNT(C_Name) from Products_Details where C_Name = '" + cname + "';";
                    SqlCommand command_count = new SqlCommand(queryString1_count, connection);


                    SqlDataReader reader_count = command_count.ExecuteReader();

                    // Call Read before accessing data.
                    while (reader_count.Read())
                    {
                        ReadSingleRow1_reader_count((IDataRecord)reader_count);
                    }

                    // Call Close when done reading.
                    reader_count.Close();
                }
                void ReadSingleRow1(IDataRecord record)
                {
                    // Console.WriteLine(String.Format("{0}", record[0]));
                    cell1.Text = String.Format("{0}", record[0]);
                    cname = cell1.Text;
                    // cell1.BorderStyle = BorderStyle.Solid;
                    //cell1.CssClass = "tablebd";
                    cell1.Width = System.Web.UI.WebControls.Unit.Pixel(150);
                    

                    row1.Cells.Add(cell1);
                    // cell2.Text = String.Format("{0}", record[1]);
                    // row1.Cells.Add(cell2);
                    // Table1_c.Rows.Add(row1);

                }
                void ReadSingleRow1_reader_count(IDataRecord record)
                {
                    // Console.WriteLine(String.Format("{0}", record[0]));
                    if (cname == "")
                    {

                    }
                    else
                    {
                        cell2.Text = loc;
                        cell2.Width = Unit.Pixel(100);
                        row1.Cells.Add(cell2);
                        cell3.Controls.Add(btn);
                        cell4.Controls.Add(btn_delete);
                        row1.Cells.Add(cell3);
                        row1.Cells.Add(cell4);
                        ptn = r.ToString();
                        btn_delete.Click += new EventHandler(btn_delete_click);
                        btn.Click += new EventHandler(btn_edit_click);
                    }

                }
                // cell3.Controls.Add(btn);
                // row1.Cells.Add(cell3);
                Table1.BackColor = System.Drawing.Color.White;
                Table1.Rows.Add(row1);

                void btn_delete_click(Object sender1, EventArgs e1)
                {
                    for (int i = 1; i <= cnt; i++)
                    {
                        if (btn_delete.ID == "btn_delete_" + i)
                        {
                            // Label1.Text = btn_delete.ID.ToString();
                            Label1.Text = loc;
                            string delect_qry_cat = "Delete from Category_Details where C_ID = '"+loc+"';";
                            string delect_qry_pro = "Delete from Products_Details where C_Name = '" + cname + "';";
                            SqlConnection con_delete = new SqlConnection(ConnectionString);
                            SqlCommand command_delete_cat = new SqlCommand(delect_qry_cat, con_delete);
                            SqlCommand command_delete_pro = new SqlCommand(delect_qry_pro, con_delete);
                            con_delete.Open();
                            command_delete_cat.ExecuteNonQuery();
                            command_delete_pro.ExecuteNonQuery();
                            Response.Redirect("CategoryPage.aspx");
                            Label2.Text = cname + " has been deleted successfully.";

                        }
                    }
                   
                }

                void btn_edit_click(Object sender1, EventArgs e1)
                {
                    Session["Category_ID"] = loc;
                    Session["Category_Name"] = cname;
                    Response.Redirect("Edit_Category.aspx");
                }
            }

            //Products table display.
            void ReadSingleRow(IDataRecord record)
            {
                // Console.WriteLine(String.Format("{0}", record[0]));
                Label1.Text = String.Format("{0}", record[0]);
                
                Label1.Text = Label1.Text.ToString().Remove(0,2);
                cnt = Convert.ToInt16(Label1.Text);
            }

           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddCategoryPage.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click1(object sender, EventArgs e)
        {

        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");

        }
    }
}