﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace Applied_Project_CSAT0049
{
    public partial class ProductPage : System.Web.UI.Page
    {
        string ConnectionString = "Data Source=DIXITHG\\DIXITHSQL;Initial Catalog=TechOnline;Integrated Security=True";
        int count_products;
        string ptn;
        
        
        protected void Page_Load(object sender, EventArgs e)
        {
            string queryString_product = "SELECT MAX(P_ID) FROM Products_Details; ";
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                
                connection.Open();
                
                /***************/
                SqlCommand command_products = new SqlCommand(queryString_product, connection);
                SqlDataReader reader_products = command_products.ExecuteReader();
                // call for products table.
                while (reader_products.Read())
                {
                    ReadSingleRow_products((IDataRecord)reader_products);
                }

                // Call Close when done reading.
                reader_products.Close();
            }
            /***************/
            for (int r = 1; r <= count_products; r++)
            {
                string P_ID;
                string P_name;
                string C_name;
                string Price;
                string Quantity;
                TableRow row1 = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                TableCell cell4 = new TableCell();
                TableCell cell5 = new TableCell();
                TableCell cell6 = new TableCell();
                TableCell cell7 = new TableCell();
                Button btn = new Button();
                btn.ID = "btn12" + r;
                btn.Text = "Edit";
                btn.ForeColor = System.Drawing.Color.White;
                btn.BackColor = System.Drawing.Color.Maroon;
                Button btn_delete = new Button();
                btn_delete.ID = "btn_delete_" + r;
                btn_delete.Text = "Delete";
                btn_delete.ForeColor = System.Drawing.Color.White;
                btn_delete.BackColor = System.Drawing.Color.Maroon;
                string loc = "P_" + r;
                string queryString1 = "SELECT P_ID, P_Name, C_Name, P_Price, Quantity from Products_Details where P_ID = '" + loc + "';";

                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    SqlCommand command = new SqlCommand(queryString1, connection);
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    // Call Read before accessing data.
                    while (reader.Read())
                    {
                        ReadSingleRow1((IDataRecord)reader);
                    }

                    // Call Close when done reading.
                    reader.Close();

                }
                void ReadSingleRow1(IDataRecord record)
                {
                    // Console.WriteLine(String.Format("{0}", record[0]));
                    cell1.Text = String.Format("{0}", record[0]);
                    // cell1.BorderStyle = BorderStyle.Solid;
                    cell1.Width = Unit.Pixel(90);
                    P_ID = cell1.Text;
                    row1.Cells.Add(cell1);
                    cell2.Text = String.Format("{0}", record[1]);
                    cell2.Width = Unit.Pixel(175);
                    P_name = cell2.Text;
                    row1.Cells.Add(cell2);
                    cell3.Text = String.Format("{0}", record[2]);
                    cell3.Width = Unit.Pixel(140);
                    C_name = cell3.Text;
                    row1.Cells.Add(cell3);
                    cell4.Text = String.Format("{0}", record[3]);
                    cell4.Width = Unit.Pixel(140);
                    Price = cell4.Text;
                    row1.Cells.Add(cell4);
                    cell5.Text = String.Format("{0}", record[4]);
                    cell5.Width = Unit.Pixel(170);
                    Quantity = cell5.Text;
                    row1.Cells.Add(cell5);
                    Table1.Rows.Add(row1);
                    Table1.BackColor = System.Drawing.Color.White;
                    /***************************/
                    if (P_ID == "")
                    {

                    }
                    else
                    {
                        
                        //cell2.Width = Unit.Pixel(100);
                        cell6.Controls.Add(btn);
                        cell7.Controls.Add(btn_delete);
                        row1.Cells.Add(cell6);
                        row1.Cells.Add(cell7);
                        ptn = r.ToString();
                        btn_delete.Click += new EventHandler(btn_delete_click);
                        btn.Click += new EventHandler(btn_edit_click);
                    }

                }
                void btn_delete_click(Object sender1, EventArgs e1)
                {
                    for (int i = 1; i <= count_products; i++)
                    {
                        if (btn_delete.ID == "btn_delete_" + i)
                        {
                            // Label1.Text = btn_delete.ID.ToString();
                            string delect_qry_pro = "Delete from Products_Details where P_ID = '" + P_ID + "';";
                            SqlConnection con_delete = new SqlConnection(ConnectionString);
                            SqlCommand command_delete_pro = new SqlCommand(delect_qry_pro, con_delete);
                            con_delete.Open();
                            command_delete_pro.ExecuteNonQuery();
                            Response.Redirect("ProductPage.aspx");
                            Label2_msg.Text = P_name + " has been deleted successfully.";

                        }
                    }

                }

                void btn_edit_click(Object sender1, EventArgs e1)
                {
                    Session["Product_ID"] = P_ID;
                    Session["Product_Name"] = P_name;
                    Session["C_Name"] = C_name;
                    Session["Price"] = Price;
                    Session["Quantity"] = Quantity;
                    Response.Redirect("Edit_Product.aspx");
                }
            }
            void ReadSingleRow_products(IDataRecord record)
            {
                // Console.WriteLine(String.Format("{0}", record[0]));
                string count_p = String.Format("{0}", record[0]);
                string count_p_Convert = count_p.Remove(0,2);
                count_products = Convert.ToInt16(count_p_Convert);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddProductPage.aspx");
        }
    }
}