﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Applied_Project_CSAT0049
{
    public partial class Edit_Product : System.Web.UI.Page
    {
        string ConnectionString = "Data Source=ramyakrishna\\ramyasql;Initial Catalog=TechOnline;Integrated Security=True";
        string P_Pid;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1_ID.Text = Session["Product_ID"].ToString();
            P_Pid = Label1_ID.Text;
            /*
            string P_name_edit_product = Session["Product_Name"].ToString();
            string Pro_cname = Session["C_Name"].ToString();
            string Pro_Price = Session["Price"].ToString();
            string Pro_Quantity = Session["Quantity"].ToString();
            */
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");

        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            
            SqlConnection Edit_Con = new SqlConnection(ConnectionString);
            Edit_Con.Open();
            string Edit_Qry_product = "UPDATE Products_Details SET P_Name = '"+ TextBox1_Pname.Text.ToString() + "', C_Name = '"+ DropDownList1.Text.ToString() + "', P_Price = '"+ TextBox3_price.Text.ToString() + "', Quantity = '"+ TextBox4_Quantity.Text.ToString() + "' from Products_Details where P_ID = '" + P_Pid + "';";
            SqlCommand edit_prod_cmd = new SqlCommand(Edit_Qry_product, Edit_Con);
            edit_prod_cmd.ExecuteNonQuery();
            Label2_errMsg.Text = "Values updated successfully....";
            
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}